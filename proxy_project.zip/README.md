# Proxy para OneDrive / SharePoint

Este projeto cria um endpoint capaz de baixar arquivos Excel diretamente do OneDrive/SharePoint e servir ao frontend sem erros de CORS.

## Endereço do proxy
`/api/proxy?url=ARQUIVO_DO_ONEDRIVE`

## Deploy
1. Faça upload no GitHub.
2. Importe no Vercel.
3. Use a URL gerada no seu painel.
